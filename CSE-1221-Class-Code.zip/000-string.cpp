#include <iostream>
#include <string>
using namespace std;

int main()
{
    string s1, s2, s3;

    s1 = "Hello"; /// strcpy()
    s2 = s1; /// strcpy()
    s3 = "C++"; /// strcpy()


//    cout << s2 << endl;
//    cout << s3.size() << endl; /// strlen()

//    if (s1 > s3) { /// strcmp
//        cout << "YES\n";
//    }
//    else {
//        cout << "NO\n";
//    }
    s2 = s1 + " " + s3; /// strcat()
//    cout << s2 << endl;
    s2[4] = 'Q';

    for (int i = 0; i < s2.size(); i++) {
        cout << s2[i];
    }

    return 0;
}










