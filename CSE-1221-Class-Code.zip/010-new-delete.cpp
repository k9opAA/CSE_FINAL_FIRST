#include <iostream>
#include <cstdlib>
using namespace std;

class A
{
    int x;
public:
    A(int a) { x = a; }
    void set(int x) { this->x = x; }
    int get() { return x; }
};

int main()
{
    int n, *data;
    cout << "Size: ";
    cin >> n; /// 10^9
//    int data[n];
//    data = (int *) malloc(n * 4); /// 4GB
//    data = new int; /// new(int)
    data = new int[n]; /// new(int)

    if (data == NULL) {
        cout << "Allocation Error\n";
        return 1;
    }

    for (int i = 0; i < n; i++) {
        data[i] = i * i;
    }
    for (int i = 0; i < n; i++) {
        cout << "data[" << i << "] = " << data[i] << endl;
    }
//    *data = 102;
//    cout << *data << endl;
//    cout << sizeof(int) << endl;
//    cout << sizeof(n) << endl;
//    cout << sizeof n << endl;

//    free(data);
//    delete data;
    delete [] data;

//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
//    cout << "Hello" << endl;
    return 0;
}



























