#include <iostream>
#include <string>
using namespace std;

void date(int d, int m, int y)
{
    cout << d << "/" << m << "/" << y << endl;
}
int date(int d, int m, int y)
{
    cout << d << "/" << m << "/" << y << endl;
    return 0;
}
void date(double d, double m, double y)
{
    cout << d << "." << m << "." << y << endl;
}
void date(string d)
{
    cout << d << endl;
}

int main()
{
    date(16, 1, 2024);
    date(25.6, 1.25, 20.24);
    date("16-01-24");

    return 0;
}












