#include <iostream>
using namespace std;

class A
{
    int *p;
public:
    A(int val)
    {
        p = new int;
        *p = val;
    }
    void change(int val) { *p = val; }
    int get() { return *p; }
};

int main()
{
    A ob1(5);
    cout << ob1.get() << endl;
    ob1.change(7);
    cout << ob1.get() << endl;

    A ob2 = ob1;
    cout << ob2.get() << endl;
    ob2.change(17);

    cout << ob1.get() << endl;
}







