#include <iostream>
using namespace std;

int area(int h, int w = 0);

int main()
{
    cout << area(5, 7) << endl;
    cout << area(5) << endl;
}

int area(int h, int w)
{
    if (w == 0) w = h;
    return h * w;
}
