#include <iostream>
#include <string>
using namespace std;

class Student
{
private:
    int roll;
    string name;
    int semester;
    double cgpa;

public:
    void init();
    Student();
    ~Student();
    Student(int s, double c);
    Student(string n, int r, int s);
    Student(string n, int r, int s, double c);
    void setRoll(int r);
    void setName(string n);
    void setSemester(int s);
    void setCGPA(double c);

    int getRoll();
    string getName();
    int getSemester();
    double getCGPA();
};
void Student::init()
{
    semester = 1;
    cgpa = 0.0;
}

Student::Student()
{
    semester = 1;
    cgpa = 0.0;
}
Student::~Student()
{
    cout << "Destructing " << semester << endl;
}

Student::Student(int s, double c)
{
    semester = s;
    cgpa = c;
    cout << "Constructing " << s << endl;
}
Student::Student(string n, int r, int s)
{
    name = n;
    roll = r;
    semester = s;
}
Student::Student(string n, int r, int s, double c)
{
    name = n;
    roll = r;
    semester = s;
    cgpa = c;
}

void Student::setRoll(int r)
{
    roll = r;
}

int Student::getRoll()
{
    return roll;
}

void Student::setName(string n)
{
    name = n;
}

string Student::getName()
{
    return name;
}

void Student::setSemester(int s)
{
    semester = s;
}

int Student::getSemester()
{
    return semester;
}

void Student::setCGPA(double c)
{
    cgpa = c;
}

double Student::getCGPA()
{
    return cgpa;
}

void fun()
{
    Student f1, f2(3, 2.2);
}

int main()
{
    Student s1("Karim", 2, 3);
//    s1.init();

//    s1.setRoll(12);
//    s1.setName("Hasan");
//    s1.setSemester(5);
//    s1.setCGPA(2.5);
//
    cout << "Roll: " << s1.getRoll() << endl;
    cout << "Name: " << s1.getName() << endl;

//    fun();

    cout << "Semester: " << s1.getSemester() << endl;
    cout << "CGPA: " << s1.getCGPA() << endl;

//    cout << "Semester: " << s2.getSemester() << endl;
//    cout << "CGPA: " << s2.getCGPA() << endl;
//
//    cout << "Semester: " << s3.getSemester() << endl;
//    cout << "CGPA: " << s3.getCGPA() << endl;

//    cout << 2 + 2 << endl;

//    s2.setRoll();
//    s2.getRoll();



    return 0;
}









