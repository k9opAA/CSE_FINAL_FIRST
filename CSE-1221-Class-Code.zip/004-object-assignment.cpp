#include <iostream>
using namespace std;

class A
{
    int x, y;
public:
    A() { }
    A(int a, int b) { x = a; y = b; }
    void show() { cout << "x = " << x << " y = " << y << endl; }
};

class B
{
    int x, y;
public:
    B() { }
    B(int a, int b) { x = a; y = b; }
    void show() { cout << "x = " << x << " y = " << y << endl; }
};

int main()
{
//    int a, b;
//    a = 6;
//    b = a;
//    cout << b << endl;

//    A d1(3, 7), d2;
//    d2 = d1;
//    d2.show();

    A a(5, 8);
    B b;
    b = a;
    b.show();
}
