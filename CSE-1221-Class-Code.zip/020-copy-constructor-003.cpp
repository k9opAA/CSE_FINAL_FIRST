// This program contains an error.
#include <iostream >
#include <cstdlib >
using namespace std;
class myclass
{
    int *p;
public:
    myclass(int i);
    myclass(const myclass &ob)
    {
        p = new int;
        *p = *(ob.p);
    }
    ~myclass()
    {
        delete p;
    }
    friend int getval(myclass x);
};
myclass::myclass(int i)
{
    p = new int;
    if(!p)
    {
        cout << "Allocation error\n";
        exit(1);
    }
    *p = i;
}
int getval(myclass x)
{
    return *x.p;
}

int main ()
{
    myclass a(1), b(2);
    cout << getval(a) << " " << getval(b);
    cout << "\n";
    cout << getval(a) << " " << getval(b);
    return 0;
}

