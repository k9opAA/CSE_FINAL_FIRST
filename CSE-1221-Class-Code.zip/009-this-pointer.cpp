#include <iostream>
using namespace std;

class A
{
    int x;
public:
    A(int a)
    {
        x = a; /// x = 5
    }
    void set(int x) /// local x = 10
    {
//        cout << "X: " << x << endl; /// ???
//        x = x;
        this->x = x;
    }
    int get() { return x; }
};

int main()
{
    A ob1(5), ob2(10);
//    cout << ob.get() << endl; /// 5
//
//    ob.set(10);
//    cout << ob.get() << endl;
    cout << ob1.get() << endl;
    cout << ob2.get() << endl;
}



























