#include <iostream>
using namespace std;

class A
{
    int p;
public:
    A(int x) { cout << "Constructing..." << endl; p = x; }
    int get() { return p; }
    void change(int x) { p = x; }
    ~A() { cout << "Destructing..." << endl; }
};

int square(A obj)
{
    obj.change(7);
    return obj.get() * obj.get();
}

int main()
{
    A a1(5);
    cout << square(a1) << endl;
    cout << a1.get() << endl;
}



























