#include <stdio.h>
#include <stdlib.h>

int main()
{
//    int n, *data;
//    printf("Size: ");
//    scanf("%d", &n);
////    int data[n];
//    data = malloc(n * 4);
//    for (int i = 0; i < n; i++) {
//        data[i] = i * i;
//    }
//    for (int i = 0; i < n; i++) {
//        printf("data[%d] = %d\n", i, data[i]);
//    }
    printf("%d\n", sizeof int);
}



























