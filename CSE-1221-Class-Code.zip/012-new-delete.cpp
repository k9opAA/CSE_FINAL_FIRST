#include <iostream>
#include <cstdlib>
using namespace std;

class A
{
    int x, y;
public:
    A(int a, int b) { x = a; y = b; }
    int get() { return x * y; }
};

int main()
{
    A *ob;
    ob = new A(2, 8);
    cout << ob->get() << endl;
    return 0;
}



























