#include <iostream>
using namespace std;

class A
{
    int d[5];
public:
    A() { }
    A(int a) {
        for (int i = 0; i < 5; i++) {
            d[i] = a * i;
        }
    }
    void show() {
        for (int i = 0; i < 5; i++) {
            cout << "[" << i << "] = " << d[i] << endl;
        }
        cout << endl;
    }
    void change(int idx, int val) {
        d[idx] = val;
    }
};

int main()
{
    A a1(2), a2;
    a2 = a1;
    a2.show();

    a1.change(2, 17);
    a1.show();

    a2.show();
}



























