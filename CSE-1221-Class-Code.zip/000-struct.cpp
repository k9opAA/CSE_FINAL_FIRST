#include <iostream>
using namespace std;

class Student
{
private:
    int roll;
    char name[20];
    int semester;
    double cgpa;

public:
    void setRoll()
    {
        cout << "Roll: ";
        cin >> roll;
    }

    void getRoll()
    {
        cout << "Roll: " << roll << endl;
    }
};

int main()
{
    Student s1, s2;

    s1.setRoll();
    s1.getRoll();

    s2.setRoll();
    s2.getRoll();


    return 0;
}









