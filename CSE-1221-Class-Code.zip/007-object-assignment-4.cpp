#include <iostream>
using namespace std;

class A
{
    int *p;
public:
    A() { }
    A(int x) {
        p = (int *) malloc(sizeof(int));
        *p = x;
    }
    void show() {
        cout << *p << endl;
    }
    void change(int val) {
        *p = val;
    }
    ~A() {
        free(p);
    }
};

int main()
{
    A a1(-9), a2;

    a1.show();
    a2 = a1;
    a2.show();

    a2.change(5);
    a2.show();
    a1.show();

    a1.change(65);
    a1.show();
}



























