#include <iostream>
using namespace std;

int f(int a, int b = 0, int c = 0)
{
    return a + b + c;
}

int main()
{
    cout << f(1, 2, 3) << endl;
    cout << f(1, 2) << endl;
    cout << f(1) << endl;
}

