#include <iostream>
#include <string>
using namespace std;


int main()
{
    int a,b,c, aq, bq,cq;
    scanf("%d%d%d%d%d%d",&a,&b,&c, &aq, &bq,&cq);

    if(a>160 && aq> 82){
        printf("a");
    }

    if(b>160 && bq> 82){
        printf("b");
    }

    if(c>160 && cq> 82){
        printf("c");
    }
    else{
        printf("none");
    }



    return 0;
}









