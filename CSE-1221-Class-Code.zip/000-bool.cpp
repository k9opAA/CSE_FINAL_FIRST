#include <iostream>
using namespace std;

int main()
{
    int num;
//    int positive;
    bool positive;

    cout << "Enter a number: ";
    cin >> num;
    if (num > 0) {
        positive = true;
    }
    else {
        positive = false;
    }

    cout << positive << endl;

    return 0;
}











