#include <iostream>
using namespace std;
class A
{
    int x;
public:
    A(int a) { cout << "Constructing..." << endl; x = a; }
    int get() { return x; }
    ~A() { cout << "Destructing..." << endl; }
};

void fun(A &ob)
{
    cout << ob.get() << endl;
}

int main()
{
    A t(12);
    fun(t);
    return 0;
}




























