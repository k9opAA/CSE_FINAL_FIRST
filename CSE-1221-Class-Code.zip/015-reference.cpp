#include <iostream>
using namespace std;

void exchange(int *x, int *y)
{
    int temp = *x;
    *x = *y;
    *y = temp;
}

int main()
{
    int a = 4, b = 9;
    cout << "a = " << a << ", b = " << b << endl;
    exchange(&a, &b);
    cout << "a = " << a << ", b = " << b << endl;
    return 0;
}




























