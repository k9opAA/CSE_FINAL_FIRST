#include <iostream>
using namespace std;
class A
{
public:
    A() { cout << "Constructing..." << endl; }
    ~A() { cout << "Destructing..." << endl; }
};

void fun(A ob)
{
    /// empty block
}

void fun2(A &ob)
{
    /// empty block
}

int main()
{
    A t;
//    fun(t);
    fun2(t);
    return 0;
}




























