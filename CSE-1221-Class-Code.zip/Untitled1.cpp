///MOHAMMAD ALI NITUL C233012(2AM);
#include<bits/stdc++.h>
using namespace std;

class product {
public:
    int id;
    string product_name;
    string product_company;
    float price;
    void get_info() {
        cout<< "TYPE ID NO : ";
        cin >>id;
        cout<< "TYPE PRODUCT NAME : ";
        cin>> product_name;
        cout<< "TYPE PRODUCT COMPANY : ";
        cin>> product_company;
        cout<< "TYPE PRICE : ";
        cin>> price;
    }

    friend void show_value(product);
};

void show_value(product x) {
    cout<<"ID NO : " << x.id<< endl;
    cout<<"PRODUCT NAME : "<< x.product_name << endl;
    cout<<"PRODUCT COMPANY : "<< x.product_company << endl;
    cout<<"PRICE : "<< x.price << endl;
}

int main() {
    int n, k;
    cout<<"HOW MANY PRODUCTS YOU WANT TO ENTER : ";
    cin>>n;
    product a[n];

    for(int i = 0; i<n; i++) {
        cout<<"TYPE PRODUCT INFO : " << endl;
        a[i].get_info();
    }

    cout<<"SEARCH PRODUCT INFO BY ID : ";
    cin>>k;


    for(int j = 0; j<n; j++) {
        if (a[j].id == k) {
            show_value(a[j]);
            break;
        }
        else cout<<"ID NOT FOUND!!";
    }


    return 0;
}
//For immediate assistance, please email our customer support: support@toptal.com

