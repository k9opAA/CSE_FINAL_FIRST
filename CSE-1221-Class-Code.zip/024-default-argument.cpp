#include <iostream>
using namespace std;

int f(int a = 0, int b = 0)
{
    return a + b;
}

int main()
{
    cout << f(1, 2) << endl;
    cout << f(1) << endl;
    cout << f() << endl;
}

