#include <iostream>
#include <cstdlib>
using namespace std;

class A
{
    int x, y;
public:
    A() { cout << "Constructing..." << endl; }
    int get() { return x * y; }
    ~A() { cout << "Destructing..." << endl; }
};

int main()
{
    A *ob;
    ob = new A[5];
//    A ob[5];
    delete [] ob;

    return 0;
}



























