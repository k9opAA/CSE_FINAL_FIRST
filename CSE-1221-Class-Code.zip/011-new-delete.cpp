#include <iostream>
using namespace std;

int main()
{
    int *n;
    n = new int(102);

//    *n = 102;
    cout << *n << endl;

    delete n;
    return 0;
}



























