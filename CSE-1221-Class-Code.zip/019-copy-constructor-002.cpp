#include <iostream>
using namespace std;

class A
{
    int *p;
public:
    A(int val)
    {
        p = new int;
        *p = val;
    }
    A(const A &x) /// x = ob1
    {
        p = new int;
        *p = *(x.p); /// 7
        *p *= 2;
    }
    void change(int val) { *p = val; }
    int get() { return *p; }
};

int main()
{
    A ob1(5), ob3(100);
    cout << ob1.get() << endl; /// 5
    ob1.change(7);
    cout << ob1.get() << endl; /// 7

    A ob2 = ob1;
    cout << ob2.get() << endl; /// 14
    ob2.change(17);

    cout << ob1.get() << endl; /// 7
    cout << ob2.get() << endl; /// 17

//    ob3 = ob1;
//    ob3.change(206);
//    cout << ob1.get() << endl;
}







