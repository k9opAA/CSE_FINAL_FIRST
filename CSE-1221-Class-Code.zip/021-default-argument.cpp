#include <iostream>
using namespace std;

int area(int h, int w)
{
    return h * w;
}
int area(int h)
{
    return h * h;
}

int main()
{
    cout << area(5, 7) << endl;
    cout << area(5) << endl;
}
